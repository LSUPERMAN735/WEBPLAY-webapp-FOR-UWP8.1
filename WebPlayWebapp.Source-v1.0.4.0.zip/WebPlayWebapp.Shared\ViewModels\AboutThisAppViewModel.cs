using System;

using Windows.ApplicationModel;

namespace WebPlayWebapp.ViewModels
{
    public class AboutThisAppViewModel
    {
        public string Publisher
        {
            get
            {
                return "AppStudio";
            }
        }

        public string AppVersion
        {
            get
            {
                return string.Format("{0}.{1}.{2}.{3}", Package.Current.Id.Version.Major, Package.Current.Id.Version.Minor, Package.Current.Id.Version.Build, Package.Current.Id.Version.Revision);
            }
        }

        public string AboutText
        {
            get
            {
                return "hello,voici une webapp Web-Play (exclusivement pour les appareils sous #windows)," +
    "créer avec APPSTUDIO de Microsoft.Mail:LSUPERMAN735@OUTLOOK.FR TWITTER:@LSUPERMA" +
    "N735 Facebook :LUMIA SUPEREMAN.";
            }
        }
    }
}

